export const products = [
  { id: 1, name: 'Product Name 1', price: 100, category: 'Category A', rating: 4.5, image: 'https://via.placeholder.com/150' },
  { id: 2, name: 'Product Name 2', price: 200, category: 'Category B', rating: 4.0, image: 'https://via.placeholder.com/150' },
  { id: 3, name: 'Product Name 3', price: 150, category: 'Category A', rating: 3.8, image: 'https://via.placeholder.com/150' }
];